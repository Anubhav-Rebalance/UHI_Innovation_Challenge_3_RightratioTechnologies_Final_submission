import 'package:dio/dio.dart';

class RDio {

   Future<Dio> getDioInstance() async {
    var dio = Dio();

    String appName = "Rebalance UHI Hackathon App";

    dio.interceptors.add(InterceptorsWrapper(
        onRequest:(options, handler){

          options.baseUrl = "http://localhost:5000";

          var customHeaders = {
            'content-type': 'application/json',
            'appName':appName
          };
          options.headers.addAll(customHeaders);
          // Do something before request is sent
          return handler.next(options); //continue
          // If you want to resolve the request with some custom data，
          // you can resolve a `Response` object eg: `handler.resolve(response)`.
          // If you want to reject the request with a error message,
          // you can reject a `DioError` object eg: `handler.reject(dioError)`
        },
        onResponse:(response,handler) {
          // Do something with response data
          return handler.next(response); // continue
          // If you want to reject the request with a error message,
          // you can reject a `DioError` object eg: `handler.reject(dioError)`
        },
        onError: (DioError e, handler) {
          // Do something with response error
          return  handler.next(e);//continue
          // If you want to resolve the request with some custom data，
          // you can resolve a `Response` object eg: `handler.resolve(response)`.
        }
    ));

    //For request/response logging
    dio.interceptors.add(LogInterceptor());

    return dio;
  }
}

