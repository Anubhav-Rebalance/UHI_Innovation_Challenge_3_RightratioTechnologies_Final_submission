import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:rebalance_uhi_app/models/HospitalDepartmentPrediction.dart';
import 'package:rebalance_uhi_app/models/Questions.dart';
import 'package:rebalance_uhi_app/models/Symptoms.dart';
import 'package:rebalance_uhi_app/screens/quiz/quiz_screen.dart';
import 'package:rebalance_uhi_app/screens/speechscreen.dart';
import 'package:rebalance_uhi_app/widgets/my_header.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';
import 'package:firebase_database/firebase_database.dart';
import 'constant.dart';
import 'networking/rebalance_dio.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Rebalance',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home: SpeechScreen(),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final controller = ScrollController();

  DatabaseReference databaseReference = FirebaseDatabase.instance.ref();

  double offset = 0;

  Map<String, List<Question>> symptomsToQuestionMap = {};

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.addListener(onScroll);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        controller: controller,
          children: [
            Column(children: <Widget>[
              MyHeader(
                image: "assets/icons/Drcorona.svg",
                textTop: "Rebalance",
                textBottom: "Symptom Checker",
                offset: offset,
              ),
              Text("Let us know your symptoms in detail!",
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),),
              const SizedBox(
                height: 10,
              ),

              FutureBuilder<List<Symptoms>>(
                future: _getAllSymptomsData(),
                builder: (BuildContext context, AsyncSnapshot snap) {
                  if (snap.data != null) {
                    return _getSymptomsView(snap.data);
                  } else {
                    return Container(
                        color: Colors.white,
                        child: const Center(
                            child: CircularProgressIndicator(
                                color: primaryColor)));
                  }
                },
              )
             
            ]),
          ],
        ),
      );
  }

  _getButton(String text) {
    return FittedBox(
      // width: double.maxFinite,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            primary: primaryColor,
            onPrimary: Colors.white,
            elevation: 0.0,
            // padding: ,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
          onPressed: () async {
            await _saveToSharedPrefrences(text,symptomsToQuestionMap[text]!);

            Get.to(QuizScreen(text, symptomsToQuestionMap[text]!));
            // onPressed();
          },
        ));
  }


  Future<List<Symptoms>> _getAllSymptomsData() async {
    debugPrint("hi");

    var dio = await RDio().getDioInstance();

    String url = "/symptoms";

    final response = await dio.get(url);
    var responseData = response.data;
    // print (jsonDecode(responseData["data"]));

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      print(responseData);

      List<Symptoms> symptomsList = [];
      for (var i in responseData) {
        print (i);
        symptomsList.add(Symptoms.fromJson(i));
      }
      print("hello");

      symptomsToQuestionMap = { for (Symptoms v in symptomsList) v.symptomName!: v.questions! };

      return symptomsList;
    }

    throw Exception("Error fetching Prediction");
  }

  Widget _getSymptomsView(List<Symptoms> symptomsList) {

    var symptomButtons = <Widget>[];

    for (Symptoms symptoms in symptomsList) {
      symptomButtons.add(_getButton(symptoms.symptomName!));
    }

    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(horizontal: 30),
      child: Wrap(runSpacing: 5.0, spacing: 5.0, children: symptomButtons),
    );
  }

  _saveToSharedPrefrences(String symptom, List<Question> questions) async {
    final prefs = await SharedPreferences.getInstance();

    prefs.clear();

    for (Question question in questions) {
      prefs.setStringList(question.question!, question.options!);
    }

    prefs.setString("Symptom", symptom);
  }
}
