import 'package:rebalance_uhi_app/models/Questions.dart';

class Symptoms {
  String? symptomName;
  List<Question>? questions = <Question>[];

  Symptoms({this.symptomName, this.questions});

  Symptoms.fromJson(Map<String, dynamic> json) {
    symptomName = json['name'];
    print(json.keys);
    int index = 1;
    var list = json.values;

    for (var quest in list) {
      if (symptomName == quest) continue;

      for (String key in quest.keys) {
        print("Quest");
        print(quest);
        print(quest[key]);
        questions?.add(Question.fromJson(key, List<String>.from(quest[key]), index++));
      }

    }
  }
}