class SelectedQnA {
  String? symptom;
  List<String>? questions;

  SelectedQnA({this.symptom, this.questions});

  SelectedQnA.fromJson(Map<String, dynamic> json) {
    symptom = json['symptom'];
    questions = json['questions'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['symptom'] = this.symptom;
    data['questions'] = this.questions;
    return data;
  }
}