class Question {
  final int id;
  String? question;
  List<String>? options;

  Question({required this.id, required this.question, required this.options});

  Question.fromJson(this.question, this.options, this.id) {
    // print("Inside Question");
    // print(json.keys.first);
    // print(List<String>.from(json[json.keys.first]));
    // print("Inside Question");
    // question = json.keys.first;
    // options = List<String>.from(json[json.keys.first]);
  }

  static Map<String, dynamic> toJson(Question question) {
    return {
      "question": question.question,
      "options":question.options
    };
  }
}

const List sample_data = [
  {
    "id": 1,
    "question":
    "is your problem",
    "options": ["Ongoing or recurrent (weeks to years)", "Recent (days to weeks)", "Sudden (hours to days)"],
    "answer_index": 1,
  },
  {
    "id": 2,
    "question": "When google release Flutter.",
    "options": ['Jun 2017', 'Jun 2017', 'May 2017', 'May 2018'],
    "answer_index": 2,
  },
  {
    "id": 3,
    "question": "A memory location that holds a single letter or number.",
    "options": ['Double', 'Int', 'Char', 'Word'],
    "answer_index": 2,
  },
  {
    "id": 4,
    "question": "What command do you use to output data to the screen?",
    "options": ['Cin', 'Count>>', 'Cout', 'Output>>'],
    "answer_index": 2,
  },
];