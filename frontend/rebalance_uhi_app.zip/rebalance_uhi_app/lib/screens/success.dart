import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:rebalance_uhi_app/main.dart';
import 'package:rebalance_uhi_app/screens/speechscreen.dart';

import '../constant.dart';
import '../widgets/my_header.dart';

class SuccessScreen extends StatelessWidget {
  const SuccessScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          MyHeader(
            image: "assets/icons/Drcorona.svg",
            textTop: "Thank You!",
            textBottom: "Team Rebalance",
            offset: 0,
          ),
          const SizedBox(height: 50,),
          Center(
            child: _getButton("Do another checkup."),
          )
        ],
      ),
    );
  }

  _getButton(String text) {
    return FittedBox(
      // width: double.maxFinite,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            primary: primaryColor,
            onPrimary: Colors.white,
            elevation: 0.0,
            // padding: ,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
          onPressed: () async {
            Get.offAll(HomeScreen());
            // onPressed();
          },
        ));
  }

}
