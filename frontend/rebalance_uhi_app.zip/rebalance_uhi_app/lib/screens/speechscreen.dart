import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:highlight_text/highlight_text.dart';
import 'package:rebalance_uhi_app/main.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../constant.dart';
import '../models/HospitalDepartmentPrediction.dart';
import '../networking/rebalance_dio.dart';
import '../widgets/my_header.dart';

class SpeechScreen extends StatefulWidget {
  @override
  _SpeechScreenState createState() => _SpeechScreenState();
}

class _SpeechScreenState extends State<SpeechScreen> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  bool _isTextEntered = false;
  String _text = 'Press the button and let us know your concern';

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
  }

  double offset = 0;
  final controller = ScrollController();

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Confidence: ${(_confidence * 100.0).toStringAsFixed(1)}%'),
      // ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: AvatarGlow(
        animate: _isListening,
        glowColor: Theme.of(context).primaryColor,
        endRadius: 75.0,
        duration: const Duration(milliseconds: 2000),
        repeatPauseDuration: const Duration(milliseconds: 100),
        repeat: true,
        child: FloatingActionButton(
          onPressed: _listen,
          child: Icon(_isListening ? Icons.mic : Icons.mic_none),
        ),
      ),
      body: SingleChildScrollView(
        controller: controller,
        reverse: true,
        child: Column(
          children: [
            MyHeader(
              image: "assets/icons/coronadr.svg",
              textTop: "Natural Language",
              textBottom: "Triage",
              offset: offset,
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 10),
              child: Text(
                _text,
                style: const TextStyle(
                  fontSize: 32.0,
                  color: Colors.black,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
            Container(
              // padding: const EdgeInsets.symmetric(vertical: 30),
              child: _isTextEntered && !_isListening ?
              FutureBuilder<DepartmentPrediction>(
                future: _getHospitalDepartmentToReferThePatientTo(_text),
                builder: (BuildContext context, AsyncSnapshot snap) {
                  if (snap.data != null) {
                    return _getHospitalDepartmentView(snap.data);
                  } else {
                    return Container(
                        color: Colors.white,
                        child: const Center(
                            child: CircularProgressIndicator(
                                color: primaryColor)));
                  }
                },
              ): Container(),
            )
          ],
        ),
      ),
    );
  }

  void _listen() async {
    if (!_isListening) {
      bool available = await _speech.initialize(
        onStatus: (val) => print('onStatus: $val'),
        onError: (val) => print('onError: $val'),
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (val) => setState(() {
            _text = val.recognizedWords;
          }),
        );
      }
    } else {
      setState(() => {
        _isListening = false,
        _isTextEntered = true
      });
      _speech.stop();
    }
  }


  Future<DepartmentPrediction> _getHospitalDepartmentToReferThePatientTo(
      String text) async {
    debugPrint("hi");

    var dio = await RDio().getDioInstance();

    String url = "/predict?text=" + text;

    final response = await dio.get(url);
    var responseData = response.data;
    // print (jsonDecode(responseData["data"]));

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      print(responseData);
      return DepartmentPrediction.fromJson(responseData);
    }

    throw Exception("Error fetching Prediction");
  }

  Widget _getHospitalDepartmentView(DepartmentPrediction data) {
    return Container(
      height: 300,
      padding: const EdgeInsets.symmetric(vertical: 30),
      width: double.maxFinite,
      child: Expanded(
        child: Column(
          children: [
            Text("Hospital Departments that you can visit!",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),),
            const SizedBox(
              height: 10,
            ),
            _getButton(data.first!),
            const SizedBox(
              height: 10,
            ),
            _getButton(data.second!),
            const SizedBox(
              height: 10,
            ),
            _getButton(data.third!),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }

  _getButton(String text) {
    return FractionallySizedBox(
        widthFactor: 0.7,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            primary: primaryColor,
            onPrimary: Colors.white,
            elevation: 0.0,
            // padding: ,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
          onPressed: () {
            Get.to(HomeScreen());
            // onPressed();
          },
        ));
  }

}
