import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/question_controller.dart';
import '../../models/Questions.dart';
import 'components/body.dart';

class QuizScreen extends StatelessWidget {
  final String text;
  final List<Question> questionsList;
  QuizScreen(this.text, this.questionsList);

  @override
  Widget build(BuildContext context) {
    print(text);
    print(questionsList);
    // print(questionsList[text]![0].question);

    QuestionController _controller = Get.put(QuestionController());
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        // Fluttter show the back button automatically
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          FlatButton(onPressed: _controller.nextQuestion, child: Text("Skip")),
        ],
      ),
      body: Body(),
    );
  }
}