import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:get/state_manager.dart';
import 'package:rebalance_uhi_app/models/SelectedQuestionsAndAnswers.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/Questions.dart';
import '../networking/rebalance_dio.dart';
import '../screens/success.dart';

// We use get package for our state management

class QuestionController extends GetxController
    with StateMixin {
  // Lets animated our progress bar

  // late AnimationController _animationController;
  // late Animation _animation;
  // // so that we can access our animation outside
  // Animation get animation => this._animation;

  late PageController _pageController;
  PageController get pageController => this._pageController;

  var questionsList = <Question>[].obs;
  // List<Question> get questions => this._questions.obs;

  var _selectedQnAs = <String>[].obs;

  bool _isAnswered = false;
  bool get isAnswered => this._isAnswered;

  late int _correctAns;
  int get correctAns => this._correctAns;

  late int _selectedAns;
  int get selectedAns => this._selectedAns;

  // for more about obs please check documentation
  RxInt _questionNumber = 1.obs;
  RxInt get questionNumber => this._questionNumber;

  int _numOfCorrectAns = 0;
  int get numOfCorrectAns => this._numOfCorrectAns;

  // called immediately after the widget is allocated memory
  @override
  Future<void> onInit() async {
    // Our animation duration is 60 s
    // so our plan is to fill the progress bar within 60s
    // _animationController =
    //     AnimationController(duration: Duration(seconds: 60), vsync: this);
    // _animation = Tween<double>(begin: 0, end: 1).animate(_animationController)
    //   ..addListener(() {
    //     // update like setState
    //     update();
    //   });
    //
    // // start our animation
    // // Once 60s is completed go to the next qn
    // _animationController.forward().whenComplete(nextQuestion);


    _pageController = PageController();

    super.onInit();

    await _getQuestionsFromSharedPrefs();
    update();
    refresh();
  }

  Future<List<Question>> _getQuestionsFromSharedPrefs() async {
    final prefs = await SharedPreferences.getInstance();

    Set<String> prefKeys = prefs.getKeys();

    int index = 1;

    List<Question> _questionList = [];

    for(String key in prefKeys) {
      if (key != "Symptom") {
        _questionList.add(Question(id: index++, question: key, options: prefs.getStringList(key)));
      }
    }

    questionsList.assignAll(_questionList);
    print("keys");

    return _questionList;

  }

  // // called just before the Controller is deleted from memory
  @override
  void onClose() {
    super.onClose();
    // _animationController.dispose();
    _pageController.dispose();
  }

  void checkAns(Question question, int selectedIndex) {
    // because once user press any option then it will run
    _isAnswered = true;
    // _correctAns = question.answer;
    _selectedAns = selectedIndex;

    print("_selectedQnAs");
    print(_selectedQnAs);
    _selectedQnAs.add(question.question! + ": " + question.options![selectedIndex]);
    print(_selectedQnAs);

    print(question.question);
    print(question.options);
    // if (_correctAns == _selectedAns) _numOfCorrectAns++;

    // It will stop the counter
    // _animationController.stop();
    update();

    // Once user select an ans after 3s it will go to the next qn
    Future.delayed(Duration(milliseconds: 300), () {
      nextQuestion();
    });
  }

  Future<void> nextQuestion() async {
    if (_questionNumber.value != questionsList.length) {
      _isAnswered = false;
      _pageController.nextPage(
          duration: Duration(milliseconds: 250), curve: Curves.ease);

      // Reset the counter
      // _animationController.reset();

      // Then start it again
      // Once timer is finish go to the next qn
      // _animationController.forward().whenComplete(nextQuestion);
    } else {
      // Get package provide us simple way to naviigate another page

      var dio = await RDio().getDioInstance();
      String url = "/save-symptoms";

      final prefs = await SharedPreferences.getInstance();

      final response = await dio.post(url,
          data: json.encode(SelectedQnA(symptom: prefs.getString("Symptom")!, questions: _selectedQnAs).toJson()));


      Get.to(SuccessScreen());
    }
  }

  void updateTheQnNum(int index) {
    _questionNumber.value = index + 1;
  }
}