package com.example.rebalance_uhi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
